import pickle
import numpy as np
from scipy.sparse import lil_matrix

def cal_jaccard_similarity(vector1, vector2):
    indices_vector1 = set(vector1.nonzero()[1])
    indices_vector2 = set(vector2.nonzero()[1])

    intersection_size = len(indices_vector1.intersection(indices_vector2))
    union_size = len(indices_vector1.union(indices_vector2))

    if union_size == 0:
        return 0.
    else:
        return intersection_size / union_size


def filter_and_get_top_indices(data, top_n=3):
    indices = [None] * data.shape[0]

    for i, row in enumerate(data):
        row_mean = np.mean(row)
        filtered_indices = np.where(row > row_mean)[0]
        filtered_values = row[filtered_indices]

        indices[i] = filtered_indices[np.argsort(filtered_values)[-top_n:]]

    return indices


def gen_sc_tail_lst(tar_beh, aux_beh):
    tar_beh = 1 * (tar_beh != 0)
    aux_beh = 1 * (aux_beh != 0)

    num_users = tar_beh.shape[0]
    num_items = tar_beh.shape[1]
    sc_score = np.zeros(num_items)

    for i in range(num_users):
        row1 = tar_beh.getrow(i)
        row2 = aux_beh.getrow(i)

        similarity = cal_jaccard_similarity(row1, row2)

        for item in row1.tocoo().col:
            sc_score[item] += similarity

    mean = np.mean(sc_score)

    sc_item_lst = np.where((sc_score > 0) & (sc_score < mean))[0]

    appear_freq = lil_matrix((num_items, num_items))

    wo_buy_mat = aux_beh - tar_beh
    wo_buy_mat = 1 * (wo_buy_mat > 0)

    for sc_item in sc_item_lst:
        user_lst = tar_beh.getcol(sc_item).nonzero()[0]

        sampled_user_inter_lst = wo_buy_mat[user_lst, :].sum(axis=0)
        appear_freq[sc_item] = sampled_user_inter_lst

    appear_freq.setdiag(0)
    tail_list = filter_and_get_top_indices(appear_freq.toarray(), 3)
    return tail_list

def gen_beh_kg(tar_beh, aux_beh, beh, tail_list):
    tar_beh = tar_beh.tocsc()
    aux_beh = aux_beh.tocsc()

    kg = np.empty((0, 4), int)
    for h, tails in enumerate(tail_list):
        if len(tails) <= 0:
            continue

        heads = np.full(len(tails), h)
        r = np.full(len(tails), beh)
        
        tar_avg_time = np.mean(tar_beh[:, h].data)

        t_gap = []
        for t in tails:
            aux_avg_time = np.mean(aux_beh[:, t].data)
            t_gap.append(abs(int(tar_avg_time - aux_avg_time)))
        
        kg = np.vstack((kg, np.stack((heads, r, tails, t_gap), axis=1)))

    if kg.shape[0] > 0:
        percentiles = np.percentile(kg[:, -1], np.linspace(0, 100, 32))
        kg[:, -1] = np.digitize(kg[:, -1], bins=percentiles, right=True)

    return kg


if __name__ == "__main__":
    behaviors = ['fav', 'cart', 'buy']

    trn_list = [None] * len(behaviors)
    for i, beh in enumerate(behaviors):
        trn_list[i] = pickle.load(open(f'./trn_{beh}', 'rb'))

    kg = np.empty((0, 4), int)

    for i in range(len(behaviors) - 1):
        print(behaviors[i])
        tail_list = gen_sc_tail_lst(trn_list[-1], trn_list[i])
        beh_kg = gen_beh_kg(trn_list[-1], trn_list[i], i, tail_list)
        kg = np.vstack((kg, beh_kg))

    print(kg.shape)
    np.save('./kg.npy', kg)
